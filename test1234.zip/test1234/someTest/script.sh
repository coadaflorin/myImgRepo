#! /bin/sh 
echo hello world, from a script file!